from __future__ import annotations

import re


_CODES = {
    **dict.fromkeys("bfpv", "1"),
    **dict.fromkeys("cgjkqsxz", "2"),
    **dict.fromkeys("dt", "3"),
    "l": "4",
    **dict.fromkeys("mn", "5"),
    "r": "6",
}


def normalize_word(word: str) -> str:
    return re.sub(r"[^a-z0-9]", "", word.lower())


def soundex(word: str) -> str:
    """Return the classic four-character Soundex code for an English word."""
    word = normalize_word(word)
    if not word:
        return ""
    first = word[0]
    encoded: list[str] = []
    previous = _CODES.get(first, "")
    for char in word[1:]:
        code = _CODES.get(char, "")
        if code and code != previous:
            encoded.append(code)
        previous = code
    return (first.upper() + "".join(encoded) + "000")[:4]
