from __future__ import annotations

from difflib import SequenceMatcher

from .language_model import NGramLanguageModel
from .soundex import normalize_word, soundex
from .tokenize import detokenize, is_word, tokenize


class SoBERTCorrector:
    """Soundex-enhanced post-processor for ASR transcripts."""

    def __init__(
        self,
        language_model: NGramLanguageModel,
        *,
        similarity_threshold: float = 0.55,
        replace_known_words: bool = False,
    ) -> None:
        self.language_model = language_model
        self.similarity_threshold = similarity_threshold
        self.replace_known_words = replace_known_words

    def _best_replacement(self, word: str, previous_word: str | None) -> str | None:
        normalized = normalize_word(word)
        if not normalized:
            return None
        if not self.replace_known_words and normalized in self.language_model.vocabulary():
            return None
        code = soundex(normalized)
        if not code:
            return None
        candidates = self.language_model.candidates(previous_word)
        scored: list[tuple[float, str]] = []
        for candidate in candidates:
            if candidate == normalized:
                continue
            if soundex(candidate) != code:
                continue
            sim = SequenceMatcher(None, normalized, candidate).ratio()
            if sim >= self.similarity_threshold:
                scored.append((sim, candidate))
        if not scored:
            return None
        return sorted(scored, reverse=True)[0][1]

    def correct(self, text: str) -> str:
        tokens = tokenize(text)
        output: list[str] = []
        previous_word: str | None = None
        for token in tokens:
            if is_word(token):
                replacement = self._best_replacement(token, previous_word)
                chosen = replacement or token
                output.append(chosen)
                previous_word = normalize_word(chosen)
            else:
                output.append(token)
        return detokenize(output)
