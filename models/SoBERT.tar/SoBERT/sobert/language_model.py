from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path

from .tokenize import is_word, tokenize


class NGramLanguageModel:
    """Simple unigram/bigram language model for SoBERT candidate generation."""

    def __init__(self, max_candidates: int = 8) -> None:
        self.max_candidates = max_candidates
        self.unigrams: Counter[str] = Counter()
        self.bigrams: dict[str, Counter[str]] = defaultdict(Counter)

    def fit(self, texts: list[str]) -> "NGramLanguageModel":
        for text in texts:
            words = [tok.lower() for tok in tokenize(text) if is_word(tok)]
            previous = "<s>"
            for word in words:
                self.unigrams[word] += 1
                self.bigrams[previous][word] += 1
                previous = word
            self.bigrams[previous]["</s>"] += 1
        return self

    @classmethod
    def from_file(cls, path: str | Path, max_candidates: int = 8) -> "NGramLanguageModel":
        lines = [line.strip() for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
        return cls(max_candidates=max_candidates).fit(lines)

    def candidates(self, previous_word: str | None) -> list[str]:
        key = previous_word.lower() if previous_word else "<s>"
        counter = self.bigrams.get(key)
        if counter:
            return [w for w, _ in counter.most_common(self.max_candidates) if w != "</s>"]
        return [w for w, _ in self.unigrams.most_common(self.max_candidates)]

    def vocabulary(self) -> set[str]:
        return set(self.unigrams)
