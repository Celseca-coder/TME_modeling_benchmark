from __future__ import annotations

import re


TOKEN_RE = re.compile(r"[A-Za-z0-9]+(?:'[A-Za-z0-9]+)?|[^\w\s]", re.UNICODE)
WORD_RE = re.compile(r"^[A-Za-z0-9]+(?:'[A-Za-z0-9]+)?$")


def tokenize(text: str) -> list[str]:
    return TOKEN_RE.findall(str(text))


def is_word(token: str) -> bool:
    return bool(WORD_RE.match(token))


def detokenize(tokens: list[str]) -> str:
    text = ""
    for token in tokens:
        if not text:
            text = token
        elif re.match(r"^[,.;:!?)]$", token):
            text += token
        elif token in {"'", "\""}:
            text += token
        elif text.endswith("("):
            text += token
        else:
            text += " " + token
    return text
