# SoBERT

This folder contains a lightweight reproduction of the algorithmic idea in:

`SoBERT: A Soundex Based Enhancement of Robust Speech Transformer`

The paper is an ASR post-processing method, not a spatial TME model. The pipeline is:

1. Generate or load speech transcripts, usually from Whisper.
2. Build a probabilistic language model from clean reference/domain sentences.
3. For each recognized word, use the previous word to obtain likely next-word candidates.
4. Use Soundex and text similarity to replace phonetically similar recognition errors.
5. Evaluate Word Error Rate when references are available.

## Minimal transcript-only run

```bash
python -u scripts/run_sobert_asr.py \
  --transcripts-csv data/sobert/transcripts.csv \
  --text-col whisper_text \
  --reference-col reference_text \
  --corpus-file models/SoBERT/config/banking_sentences.txt \
  --output results/sobert_predictions.csv
```

## Optional audio run with Whisper

Install OpenAI Whisper first in the target environment, then run:

```bash
python -u scripts/run_sobert_asr.py \
  --audio-dir data/sobert/audio \
  --reference-csv data/sobert/references.csv \
  --id-col id \
  --reference-col reference_text \
  --corpus-file models/SoBERT/config/banking_sentences.txt \
  --whisper-model tiny \
  --output results/sobert_predictions.csv
```

The output CSV includes original transcript, SoBERT-corrected transcript, and WER before/after when references are supplied.
